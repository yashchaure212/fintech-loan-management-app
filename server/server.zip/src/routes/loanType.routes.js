import { Router } from "express";
import { loanTypeController } from "../controllers/loanType.controller.js";
import { validate } from "../middlewares/validate.middleware.js";
import {
  createLoanTypeSchema,
  updateLoanTypeSchema,
  updateLoanStatusSchema,
} from "../validations/loanType.validation.js";
import { protect } from "../middlewares/auth.middleware.js";

const router = Router();

router.post(
  "/",
  protect,
  validate(createLoanTypeSchema),
  loanTypeController.create,
);

router.get("/", protect, loanTypeController.getAll);

router.get("/:id", protect, loanTypeController.getById);

router.patch(
  "/:id",
  protect,
  validate(updateLoanTypeSchema),
  loanTypeController.update,
);

router.patch(
  "/:id/status",
  protect,
  validate(updateLoanStatusSchema),
  loanTypeController.updateStatus,
);

router.delete("/:id", protect, loanTypeController.delete);

export default router;
