import { profileService } from "../services/profile.service.js";

export const profileController = {
  async create(req, res, next) {
    try {
      const result = await profileService.createProfile(req.user.id, req.body);

      res.status(201).json({
        success: true,

        message: "Profile created successfully",

        data: result,
      });
    } catch (error) {
      next(error);
    }
  },

  async get(req, res, next) {
    try {
      const result = await profileService.getProfile(req.user.id);

      res.status(200).json({
        success: true,

        data: result,
      });
    } catch (error) {
      next(error);
    }
  },

  async update(req, res, next) {
    try {
      const result = await profileService.updateProfile(req.user.id, req.body);

      res.status(200).json({
        success: true,

        message: "Profile updated successfully",

        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
};
