import prisma from "../config/prisma.js";

export const loanApplicationRepository = {
  create(data) {
    return prisma.loanApplication.create({
      data,
      include: {
        loanType: true,
        user: true,
      },
    });
  },

  findLoanType(id) {
    return prisma.loanType.findUnique({
      where: {
        id,
      },
    });
  },

  findByUser(userId) {
    return prisma.loanApplication.findMany({
      where: {
        userId,
      },
      include: {
        loanType: true,
      },
      orderBy: {
        createdAt: "desc",
      },
    });
  },

  findById(id) {
    return prisma.loanApplication.findUnique({
      where: {
        id,
      },
      include: {
        loanType: true,
        user: true,
      },
    });
  },
};
