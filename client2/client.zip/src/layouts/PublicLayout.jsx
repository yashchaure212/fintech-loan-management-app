import { Outlet } from "react-router-dom";
import Navbar from "@/components/layout/Navbar";
import BottomNav from "@/components/layout/BottomNav";

function PublicLayout() {
  return (
    <div className="app-shell min-h-screen bg-background">
      <Navbar />
      <main className="min-w-0 pb-16 md:pb-0">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
}

export default PublicLayout;
